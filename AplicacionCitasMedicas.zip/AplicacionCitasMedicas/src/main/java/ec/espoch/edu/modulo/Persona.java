package ec.espoch.edu.modulo;
import java.util.ArrayList;

public class Persona {

    private String nombre;
    private String cedula;
    private String fecha;
    private String genero;
    private String areaMedica;
    private String motivoConsulta;

        public Persona() {
    }

    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getAreaMedica() {
        return areaMedica;
    }

    public void setAreaMedica(String areaMedica) {
        this.areaMedica = areaMedica;
    }

    public String getMotivoConsulta() {
        return motivoConsulta;
    }

    public void setMotivoConsulta(String motivoConsulta) {
        this.motivoConsulta = motivoConsulta;
    }



    public String ingresarDatos() {
        return Archivo.anexarArchivo(this.nombre, this.cedula, this.fecha,
                this.genero, this.areaMedica, this.motivoConsulta);
    }

    public ArrayList<Persona> mostrarDatos() {
        return Archivo.leerArchivo();
    }

    public void modificarDatos(String nuevoNombre, String nuevaCedula, String nuevaFecha,
            String nuevoGenero, String nuevaAreaMedica, String nuevoMotivoConsulta) {
        
        this.setNombre(nuevoNombre);
        this.setCedula(nuevaCedula);
        this.setFecha(nuevaFecha);
        this.setGenero(nuevoGenero);
        this.setAreaMedica(nuevaAreaMedica);
    }
    
    public Persona(String nombre, String cedula, String fecha, String genero, String areaMedica, String motivoConsulta) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.fecha = fecha;
        this.genero= genero;
        this.areaMedica = areaMedica;
        this.motivoConsulta =motivoConsulta;        
                }
}
