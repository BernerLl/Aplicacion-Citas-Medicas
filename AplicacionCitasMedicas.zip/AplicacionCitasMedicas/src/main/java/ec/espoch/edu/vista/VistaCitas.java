package ec.espoch.edu.vista;

import ec.espoch.edu.vista.Ingresar;
import ec.espoch.edu.controlador.ControladorCitas;
import ec.espoch.edu.modulo.Archivo;
import ec.espoch.edu.modulo.Persona;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class VistaCitas extends javax.swing.JFrame {

    DefaultTableModel model = new DefaultTableModel();

    public VistaCitas() {
        initComponents();
        ControladorCitas controlador = new ControladorCitas(this);
        controlador.procesoAgregar();
    }

    public void setModelo() {
        String[] cabecera = {"Nombre", "Cedula", "Fecha", "Genero", "Area Medica", "Motivo de Consulta"};
        model.setColumnIdentifiers(cabecera);
        tabla.setModel(model);
    }

    public void setDatos(ArrayList<Persona> personas) {
        Object[] datos = new Object[model.getColumnCount()];
        int i = 0;
        double totalVentas = 0.0;

        for (Persona persona : personas) {
            datos[0] = persona.getNombre();
            datos[1] = persona.getCedula();
            datos[2] = persona.getFecha();
            datos[3] = persona.getGenero();
            datos[4] = persona.getAreaMedica();
            datos[5] = persona.getMotivoConsulta();
           
            model.addRow(datos);
        }


    }

    public void limpiarTabla() {
        DefaultTableModel model = (DefaultTableModel) tabla.getModel();
        model.setRowCount(0);
        
    }

    public JTable getTabla() {
        return tabla;
    }

    public DefaultTableModel getModel() {
        return (DefaultTableModel) tabla.getModel();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        volver = new javax.swing.JButton();
        eliminar = new javax.swing.JButton();
        modificar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Sylfaen", 0, 18)); // NOI18N
        jLabel1.setText("Citas Pendientes:");

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tabla);

        volver.setFont(new java.awt.Font("Sylfaen", 0, 14)); // NOI18N
        volver.setText("Volver");
        volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                volverActionPerformed(evt);
            }
        });

        eliminar.setFont(new java.awt.Font("Sylfaen", 0, 14)); // NOI18N
        eliminar.setText("Eliminar");
        eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarActionPerformed(evt);
            }
        });

        modificar.setFont(new java.awt.Font("Sylfaen", 0, 14)); // NOI18N
        modificar.setText("Modificar");
        modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(volver, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(48, 48, 48))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(modificar)
                        .addGap(18, 18, 18)
                        .addComponent(eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(248, 248, 248)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 562, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(12, 12, 12)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(modificar)
                    .addComponent(eliminar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(volver)
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void volverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_volverActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_volverActionPerformed

    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
        int selectedRowIndex = tabla.getSelectedRow();

        // Check if a row is selected
        if (selectedRowIndex != -1) {
            // Obtener la cédula de la fila seleccionada
            String cedula = model.getValueAt(selectedRowIndex, 1).toString();

            // Llamar al método de tu clase Archivo para eliminar el registro con la cédula específica
            boolean eliminacionExitosa = Archivo.eliminarRegistroPorCedula(cedula);

            if (eliminacionExitosa) {
                // Si la eliminación es exitosa, entonces procede a eliminar la fila de la tabla
                model.removeRow(selectedRowIndex);

                // You may want to update your data structure (ArrayList<Persona>) accordingly here.
                // Clear the selection
                tabla.clearSelection();

                // Optionally, you may want to update the total sales after removing the row
               
            } else {
                // Muestra un mensaje de error si la eliminación no fue exitosa
                JOptionPane.showMessageDialog(this, "Error al eliminar el registro.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            // Mostrar un mensaje indicando que no se ha seleccionado ninguna fila
            JOptionPane.showMessageDialog(this, "Selecciona una fila para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_eliminarActionPerformed

    private void modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarActionPerformed
        int filaSeleccionada = tabla.getSelectedRow();
        if (filaSeleccionada != -1) {
            // Obtener datos de la fila seleccionada
            String nombre = tabla.getValueAt(filaSeleccionada, 0).toString();
            String cedula = tabla.getValueAt(filaSeleccionada, 1).toString();
            String fecha = tabla.getValueAt(filaSeleccionada, 2).toString();
            String genero = tabla.getValueAt(filaSeleccionada, 3).toString();
            String areaMedica = tabla.getValueAt(filaSeleccionada, 4).toString();
            String motivoConsulta = tabla.getValueAt(filaSeleccionada, 5).toString();


            // Crear una instancia de la interfaz de Ingresar y pasar datos
            Ingresar ingreso = new Ingresar(nombre, cedula, fecha, genero, areaMedica, motivoConsulta, this, filaSeleccionada);
            ingreso.setVisible(true);

            // Esperar hasta que se complete la modificación en la interfaz Ingresar
            // ...
            // Una vez que se completa la modificación, obtener los nuevos datos
            String nuevoNombre = ingreso.getNombre();
            String nuevaCedula = ingreso.getCedula();
            String nuevaFecha = ingreso.getFecha();
            String nuevoGenero = ingreso.getGenero();
            String nuevaAreaMedica = ingreso.getAreaMedica();
            String nuevoMotivoConsulta = ingreso.getMotivoConsulta();
            // Modificar los datos en la tabla directamente
            modificarDatosEnTabla(nuevoNombre, nuevaCedula, nuevaFecha,
                    nuevoGenero, nuevaAreaMedica, nuevoMotivoConsulta,filaSeleccionada);

            // Opcionalmente, puedes actualizar los datos en la lista de personas
            // ...
        } else {
            // Mostrar un mensaje indicando que no se ha seleccionado ninguna fila
            JOptionPane.showMessageDialog(this, "Selecciona una fila para modificar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_modificarActionPerformed


    public void modificarDatosEnTabla(String nuevoNombre ,String nuevaCedula, String nuevaFecha, String nuevoGenero, String nuevaAreaMedica, String nuevoMotivoConsulta, int filaSeleccionada) {

        model.setValueAt(nuevoNombre, filaSeleccionada, 0);
        model.setValueAt(nuevaCedula, filaSeleccionada, 1);
        model.setValueAt(nuevaFecha, filaSeleccionada, 2);
        model.setValueAt(nuevoGenero, filaSeleccionada, 3);
        model.setValueAt(nuevaAreaMedica, filaSeleccionada, 4);
        model.setValueAt(nuevoMotivoConsulta, filaSeleccionada, 5);


    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton eliminar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton modificar;
    private javax.swing.JTable tabla;
    private javax.swing.JButton volver;
    // End of variables declaration//GEN-END:variables
}
