
package ec.espoch.edu.controlador;

import ec.espoch.edu.modulo.Persona;
import ec.espoch.edu.vista.VistaCitas;


public class ControladorCitas {
    private VistaCitas citas;
    private Persona persona;
    
    public ControladorCitas(VistaCitas citas) {
        this.citas = citas;
        this.persona = new Persona();
    }
    
    public void procesoAgregar() {
        persona.mostrarDatos();
        this.citas.setModelo();
        this.citas.setDatos(this.persona.mostrarDatos());
    }
   
}
