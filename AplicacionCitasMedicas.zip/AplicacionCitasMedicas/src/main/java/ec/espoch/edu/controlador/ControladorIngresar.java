
package ec.espoch.edu.controlador;

import ec.espoch.edu.modulo.Persona;
import ec.espoch.edu.vista.Ingresar;

public class ControladorIngresar {
    
    private Ingresar ingresar;
    private Persona persona;
    
    public ControladorIngresar(Ingresar ingresar) {
        this.ingresar = ingresar;
        this.persona = new Persona();
    }
    
    public void procesoIngresar() {
        String nombre, cedula, fecha, genero, areaMedica, motivoConsulta;

        

        nombre = this.ingresar.getNombre();
        cedula = this.ingresar.getCedula();
        fecha= this.ingresar.getFecha();
        genero = this.ingresar.getGenero();
        areaMedica = this.ingresar.getAreaMedica();
        motivoConsulta =this.ingresar.getMotivoConsulta();
        
        this.persona.setNombre(nombre);
        this.persona.setCedula(cedula);
        this.persona.setFecha(fecha);
        this.persona.setGenero(genero);
        this.persona.setAreaMedica(areaMedica);
        this.persona.setMotivoConsulta(motivoConsulta);

        String msm = this.persona.ingresarDatos();
        this.ingresar.mostrarRespuesta(msm);
        this.ingresar.mostrarMensajeError("");
    }
}