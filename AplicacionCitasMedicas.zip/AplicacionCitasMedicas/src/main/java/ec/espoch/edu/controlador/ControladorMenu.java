
package ec.espoch.edu.controlador;

import ec.espoch.edu.modulo.Archivo;
import ec.espoch.edu.vista.Ingresar;
import ec.espoch.edu.vista.MenuPrincipal;
import ec.espoch.edu.vista.VistaCitas;

public class ControladorMenu {
    private MenuPrincipal menuPrincipal;
    private Ingresar ingresar;
    private VistaCitas citas;
    
    public ControladorMenu(MenuPrincipal menuPrincipal) {
        this.menuPrincipal = menuPrincipal;
        this.ingresar = new Ingresar();
        this.citas = new VistaCitas();
    }
    
    public void procesoDireccion(String accion) {

         Archivo.crearArchivo();
        switch (accion) {
            case "INGRESAR" -> ingresar.setVisible(true);
            case "LISTAR" -> citas.setVisible(true);
            default -> throw new AssertionError();
        }
     }
}
