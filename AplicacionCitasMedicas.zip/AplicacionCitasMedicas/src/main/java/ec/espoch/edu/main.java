/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.espoch.edu;

import ec.espoch.edu.vista.MenuPrincipal;

/**
 *
 * @author USUARIO
 */
public class main {
        public static void main(String[] args) {
        MenuPrincipal objMenuPrincipal = new MenuPrincipal();
        objMenuPrincipal.setVisible(true);
        objMenuPrincipal.setLocationRelativeTo(null);
    }
}
